//
//  SwiftRobotControlCenter.swift
//  MyRobot
//
//  Created by Ivan Vasilevich on 10/4/14.
//  Copyright (c) 2014 Ivan Besarab. All rights reserved.
//

import UIKit
//  All robot commands can be founded in GameViewController.h
class SwiftRobotControlCenter: RobotControlCenter {
      
    

    //  Level name setup
    override func viewDidLoad() {
        levelName = "L3C" //  Level name
        
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        super.viewDidAppear(animated)
                
                func moveToWall() {
                        
                        while frontIsClear {
                            move()
                        }
                        turnRight()
                    }
                    
                func turnLeft(){
                    for _ in 0..<3 {
                        turnRight()
                    }
                }
                    
                func makeUTurn(){
                        turnLeft()
                        move()
                        turnLeft()
                        move()
                    }
                    
                func moveAlongWall(){
                        while leftIsBlocked && frontIsClear{
                            move()
                        }
                    }
                    
                func goAroundTheWalls(){
                        moveToWall()
                        moveAlongWall()
                        makeUTurn()
                        moveAlongWall()
                        turnRight()
                    }
                    
                for _ in 0..<15 {
                    if frontIsClear{
                        move()
                    }else {
                        goAroundTheWalls()
                    }
                }
           
            }
    
}
