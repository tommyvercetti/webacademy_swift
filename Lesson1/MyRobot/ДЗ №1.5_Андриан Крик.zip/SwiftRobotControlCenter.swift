//
//  SwiftRobotControlCenter.swift
//  MyRobot
//
//  Created by Ivan Vasilevich on 10/4/14.
//  Copyright (c) 2014 Ivan Besarab. All rights reserved.
//

import UIKit
//  All robot commands can be founded in GameViewController.h
class SwiftRobotControlCenter: RobotControlCenter {
      

    //  Level name setup
    override func viewDidLoad() {
        levelName = "L666H" //  Level name
        
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        super.viewDidAppear(animated)
        
        
        func turnLeft(){
            for _ in 0..<3 {
                turnRight()
            }
        }
        
        func stepBack(){
            turnRight()
            turnRight()
            if frontIsClear {
                move()
            }
            turnRight()
        }
        
        func moveRobotInRandomPosition(){
            for _ in 0..<10 {
                if frontIsClear {
                    move()
                }
                
            }
            turnRight()
            for _ in 0..<4 {
                if frontIsClear {
                    move()
                }
                
            }
            turnRight()
            for _ in 0..<2 {
                if frontIsClear {
                    move()
                }
                
            }
            for _ in 0..<7 {
                if frontIsClear {
                    turnLeft()
                }
                
            }
            
        }
        
        func turnDown(){
            if facingRight {
                turnRight()
            }else if facingUp{
                for _ in 0..<2 {
                    turnRight()
                }
            }else if facingLeft{
                turnLeft()
            }
        }
        
        func turnUp(){
            if facingRight {
                turnLeft()
            } else if facingDown {
                for _ in 0..<2 {
                    turnRight()
                }
            } else if facingLeft{
                turnRight()
            }
        }
        
        func moveToZeroPoint(){
            turnDown()
            while frontIsClear {
                move()
            }
            turnRight()
            while frontIsClear {
                move()
            }
            for _ in 0..<2 {
                turnRight()
            }
            
        }
        
        func candyDropping(){
            if noCandyPresent {
                put()
            }
        }
       
        func placeEndpointsH(){ //horizontal endpoints
            if noCandyPresent {
                candyDropping()
            }
            while frontIsClear {
                move()
            }
            candyDropping()
            moveToZeroPoint()
        }
        
        func placeEndpointsV(){ //vertical endpoints
            if noCandyPresent {
                candyDropping()
            }
            while frontIsClear {
                move()
            }
            candyDropping()
            
            turnDown()
            while frontIsClear {
                move()
            }
            
        }
        
        func measureTheWorld(){
            move()
            while noCandyPresent {
                move()
            }
            turnRight()
            turnRight()
            move()
            candyDropping()
            move()
            
        }
        
        
        
        moveRobotInRandomPosition()
        moveToZeroPoint()
        
        if facingRight && frontIsClear {
            placeEndpointsH()
            repeat{
                measureTheWorld()
            }while noCandyPresent
            stepBack()
        }
        
        
        
        if facingUp && frontIsClear {
            placeEndpointsV()
            turnUp()
            repeat{
                measureTheWorld()
            }while noCandyPresent

            stepBack()
        }else{
            turnUp()
            placeEndpointsV()
            turnUp()
            repeat{
                measureTheWorld()
            }while noCandyPresent

            stepBack()
        }
        
        }
    
}
