//
//  SwiftRobotControlCenter.swift
//  MyRobot
//
//  Created by Ivan Vasilevich on 10/4/14.
//  Copyright (c) 2014 Ivan Besarab. All rights reserved.
//

import UIKit
//  All robot commands can be founded in GameViewController.h
class SwiftRobotControlCenter: RobotControlCenter {
      

    //  Level name setup
    override func viewDidLoad() {
        levelName = "L666H" //  Level name
        
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        super.viewDidAppear(animated)
        
        func turnLeft(){
            for _ in 0..<3 {
                turnRight()
            }
        }
        
        func turnDown(){
                    if facingRight {
                        turnRight()
                    }else if facingUp{
                        for _ in 0..<2 {
                            turnRight()
                        }
                    }else if facingLeft{
                        turnLeft()
                    }
                }
        
        func putMeInRandomPosition(){
                for _ in 0..<10 {
                    if frontIsClear {
                        move()
                    }
    
                }
                turnRight()
                for _ in 0..<4 {
                    if frontIsClear {
                        move()
                    }
    
                }
                turnRight()
                for _ in 0..<2 {
                    if frontIsClear {
                        move()
                    }
    
                }
                for _ in 0..<7 {
                    if frontIsClear {
                        turnLeft()
                    }
    
                }
    
            }
        
        func moveToZeroPoint(){
            turnDown()
                    while frontIsClear {
                        move()
                    }
                    turnRight()
                    while frontIsClear {
                        move()
                    }
                    for _ in 0..<2 {
                        turnRight()
                    }
        
                }
        
        func moveToNewPossition(){
                while frontIsClear {
                    move()
                }
            }
        
        func candyDropping(){
            if noCandyPresent {
                put()
            }
            
                moveToNewPossition()
            
            if noCandyPresent {
                put()
            }
        }
        
        
        
        putMeInRandomPosition()
        turnRight()
        turnRight()
        
        moveToZeroPoint()
        
        
        candyDropping()
        
        
        if leftIsClear && rightIsBlocked {
            turnLeft()
            moveToNewPossition()
            turnLeft()
            candyDropping()
        }
        
        
        
    }
    
}
