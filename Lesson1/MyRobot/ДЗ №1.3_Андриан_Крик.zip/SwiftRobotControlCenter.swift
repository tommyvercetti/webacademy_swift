//
//  SwiftRobotControlCenter.swift
//  MyRobot
//
//  Created by Ivan Vasilevich on 10/4/14.
//  Copyright (c) 2014 Ivan Besarab. All rights reserved.
//

import UIKit
//  All robot commands can be founded in GameViewController.h
class SwiftRobotControlCenter: RobotControlCenter {
      

    
    
    //  Level name setup
    override func viewDidLoad() {
        levelName = "L11C" //  Level name
        
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        super.viewDidAppear(animated)
        
        func turnLeft(){
            for _ in 0..<3 {
                turnRight()
            }
        }
        
        func moveRobotToStartPosition(){
            move()
        }
        
        func moveRobotToCandiesRespawnPlace(){
            for _ in 0..<2 {
                turnRight()
            }
            
            move()
            for _ in 0..<2 {
                turnRight()
            }
        }
        
        func moveRobotToExistingPosition(){
            for _ in 0..<2 {
                turnRight()
            }
            for _ in 0..<2 {
                move()
            }
            for _ in 0..<2 {
                turnRight()
            }
        }
        
        
        
        func candyGenerator(){
            for _ in 0..<2 {
                put()
            }
        }
        
        func candyMoving(){
            if candyPresent {
                pick()
            }
            move()
        }
        
        func moveCandiesBackToExistingRespawnPlace(){
            move()
            while candyPresent{
                pick()
                moveRobotToCandiesRespawnPlace()
                put()
                move()
            }
        }
        
        moveRobotToStartPosition()
        repeat {
            candyMoving()
            candyGenerator()
            moveRobotToCandiesRespawnPlace()
        }while candyPresent
        
        
        
        
        
        moveCandiesBackToExistingRespawnPlace()
        moveRobotToExistingPosition()
        
        
        
        
    }
    
}
