//
//  ViewController.swift
//  Lection2_DZ
//
//  Created by Andrian Kryk on 18.12.2019.
//  Copyright © 2019 Andrian Kryk. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //Переделать дз №2 используя в методах аргументы и возвращаемые значения - перезаливать в дз2
        //        Assignment #2. Block 2.
        //        Задача 1. Остров Манхэттен был приобретен поселенцами за $24 в 1826 г. Каково было бы в настоящее время состояние их счета, если бы эти 24 доллара были помещены тогда в банк под 6% годового дохода?
        
        manhattan(price: 24, percent: 0.06, firstYear: 1826, lastYear: 2019)
        delineator()
        
        //        Задача 2. Ежемесячная стипендия студента составляет 700 гривен, а расходы на проживание превышают ее и составляют 1000 грн. в месяц. Рост цен ежемесячно увеличивает расходы на 3%. Определить, какую нужно иметь сумму денег, чтобы прожить учебный год (10 месяцев), используя только эти деньги и стипендию.
        
        needs(scholarship: 700, expenseFirstMonth: 1000, inflation: 0.03, months: 10)
        delineator()
        
        //        Задача 3. У студента имеются накопления 2400 грн. Ежемесячная стипендия составляет 700 гривен, а расходы на проживание превышают ее и составляют 1000 грн. в месяц. Рост цен ежемесячно увеличивает расходы на 3%. Определить, сколько месяцев сможет прожить студент, используя только накопления и стипендию.
        
        needs2(scholarship: 700, expenseFirstMonth: 1000, inflation: 0.03, startBalance: 2400.0)
        delineator()
        
        //        Задача 4. 2хзначную цело численную переменную типа 25, 41, 12. После выполнения вашей программы у вас в другой переменной должно лежать это же число только задом на перед 52, 14, 21
        
        //        Пример с числом 52
        //        Вывод в консоль:
        //        Перевернув число 52 получим 25
        
        print(digitsRotation(randomNumber: 52))
        delineator()
        
    }
    
    func digitsRotation(randomNumber: Int) -> String {
        print("Number is - \(randomNumber)")
        var firstNumber = randomNumber
        var secondNumber = 0
        
        while firstNumber > 0 {
            var tempNumber = 0
            tempNumber = firstNumber % 10
            firstNumber = firstNumber / 10
            secondNumber = secondNumber * 10
            secondNumber = secondNumber + tempNumber
        }
        let result = "Rotated number is - \(secondNumber)"
        return result
    }
    
    func needs(scholarship: Double, expenseFirstMonth: Double, inflation: Double, months: Int) -> Double {
        var wholeExpence = 0.0
        var countExpence = expenseFirstMonth
        
        for _ in 0..<months-1 {
            countExpence += (countExpence*inflation)
            wholeExpence += countExpence
        }
        print("You need - \(wholeExpence+expenseFirstMonth) UAH for \(months) months")
        let result = wholeExpence+expenseFirstMonth
        return result
    }
    
    func needs2(scholarship: Double, expenseFirstMonth: Double, inflation: Double, startBalance: Double) -> Int {
        var months = 0
        var countExpence = expenseFirstMonth
        var countBalance = startBalance
        
        repeat{
            months += 1
            //print("\(months) months passed")
            
            countExpence += (countExpence * inflation)
            //print("expenseOneMonth - \(countExpence)")
            
            countBalance += scholarship + (countExpence * -1)
            //print("balance after \(months) month - \(countBalance)")
            //print("----------")
            
        }while countBalance > countExpence
        print("Sudent will die after \(months) month")
        
        return months
    }
    
    func manhattan(price: Double, percent: Double, firstYear: Int, lastYear: Int) -> Double{
        var countIncome = price
        
        for _ in firstYear...lastYear {
            countIncome = countIncome+(countIncome*percent)
        }
        print("Income in year - \(lastYear) will be - \(countIncome) USD")
        return countIncome
    }
    
    func delineator() {
        print("************************* ")
    }
}

